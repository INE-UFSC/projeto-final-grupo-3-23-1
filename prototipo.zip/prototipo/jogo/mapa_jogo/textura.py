class Textura:
    pass