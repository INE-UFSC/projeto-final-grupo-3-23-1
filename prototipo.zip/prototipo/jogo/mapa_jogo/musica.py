class Musica:
    pass