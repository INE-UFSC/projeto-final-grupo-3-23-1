from programa import Programa

programa = Programa()
programa.rodar()
